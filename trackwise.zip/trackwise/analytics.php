<?php
session_start();
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
include 'db.php';
$user_id  = $_SESSION['user_id'];
$username = $_SESSION['username'];

$user_r  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT salary FROM users WHERE id='$user_id'"));
$salary  = $user_r['salary'] ?? 0;

$cat_data = mysqli_query($conn, "SELECT c.name, SUM(e.amount) as total FROM expenses e JOIN categories c ON e.category_id=c.id WHERE e.user_id='$user_id' GROUP BY c.name ORDER BY total DESC");
$labels=[]; $amounts=[];
while($row=mysqli_fetch_assoc($cat_data)){ $labels[]=$row['name']; $amounts[]=(float)$row['total']; }

$monthly = mysqli_query($conn, "SELECT DATE_FORMAT(expense_date,'%b %Y') as month, SUM(amount) as total FROM expenses WHERE user_id='$user_id' GROUP BY YEAR(expense_date),MONTH(expense_date) ORDER BY expense_date ASC");
$months=[]; $mtotals=[];
while($row=mysqli_fetch_assoc($monthly)){ $months[]=$row['month']; $mtotals[]=(float)$row['total']; }

$grand_r = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(amount) as t, COUNT(*) as c FROM expenses WHERE user_id='$user_id'"));
$grand=$grand_r['t']??0; $count=$grand_r['c']??0;
$month_r = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(amount) as t FROM expenses WHERE user_id='$user_id' AND MONTH(expense_date)=MONTH(NOW()) AND YEAR(expense_date)=YEAR(NOW())"));
$mspend=$month_r['t']??0;
$remaining = $salary - $mspend;
$spent_pct = $salary>0?min(round(($mspend/$salary)*100),100):0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Analytics — TrackWise</title>
<link rel="stylesheet" href="css/style.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="bg-scene"></div>
<div class="bg-grid"></div>
<div class="bg-orb bg-orb-1"></div>
<div class="bg-orb bg-orb-2"></div>

<nav class="topbar">
  <a href="index.php" class="topbar-brand"><div class="icon">💰</div><div class="name">TRACKWISE</div></a>
  <div class="topbar-nav">
    <a href="add_expense.php" class="btn btn-gold btn-sm">+ Add Expense</a>
    <a href="expenses.php" class="btn btn-ghost btn-sm">📋 Expenses</a>
    <a href="salary.php" class="btn btn-ghost btn-sm">💼 Salary</a>
    <a href="index.php" class="btn btn-ghost btn-sm">🏠 Dashboard</a>
    <a href="logout.php" class="btn btn-red btn-sm">Logout</a>
  </div>
  <div class="topbar-user">
    <div class="avatar"><?= strtoupper(substr($username,0,1)) ?></div>
    <span><?= htmlspecialchars($username) ?></span>
  </div>
</nav>

<div class="main-content">
  <div class="page-header">
    <h1>Expense <span>Analytics</span></h1>
    <p>Deep insights into your spending patterns</p>
  </div>

  <!-- STAT CARDS -->
  <div class="stats-grid" style="margin-bottom:25px;">
    <div class="stat-card card-gold">
      <div class="card-icon">💰</div>
      <div class="card-label">Total Spent</div>
      <div class="card-value">₹<?= number_format($grand,0) ?></div>
    </div>
    <div class="stat-card card-green">
      <div class="card-icon">📅</div>
      <div class="card-label">This Month</div>
      <div class="card-value">₹<?= number_format($mspend,0) ?></div>
    </div>
    <?php if($salary>0): ?>
    <div class="stat-card card-blue">
      <div class="card-icon">🏦</div>
      <div class="card-label">Savings</div>
      <div class="card-value" style="color:<?= $remaining>=0?'#52c48a':'#e05252' ?>">₹<?= number_format(abs($remaining),0) ?></div>
      <div class="card-sub"><?= $remaining>=0?'Saved this month':'Over budget' ?></div>
    </div>
    <div class="stat-card card-red">
      <div class="card-icon">📊</div>
      <div class="card-label">Budget Used</div>
      <div class="card-value"><?= $spent_pct ?>%</div>
      <div class="card-sub">Of ₹<?= number_format($salary,0) ?> salary</div>
    </div>
    <?php else: ?>
    <div class="stat-card card-blue">
      <div class="card-icon">🔢</div>
      <div class="card-label">Transactions</div>
      <div class="card-value"><?= $count ?></div>
    </div>
    <div class="stat-card card-red">
      <div class="card-icon">📈</div>
      <div class="card-label">Avg Transaction</div>
      <div class="card-value">₹<?= $count>0?number_format($grand/$count,0):0 ?></div>
    </div>
    <?php endif; ?>
  </div>

  <!-- SALARY PROGRESS BAR -->
  <?php if($salary>0): ?>
  <div class="panel" style="margin-bottom:25px;">
    <div class="panel-header"><div class="panel-title">💼 <?= date('F Y') ?> Budget Tracker</div><a href="salary.php" class="btn btn-ghost btn-sm">✏️ Update Salary</a></div>
    <div style="margin-bottom:10px;">
      <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
        <span style="font-size:13px;color:var(--text-dim);">Spent: ₹<?= number_format($mspend,2) ?> (<?= $spent_pct ?>%)</span>
        <span style="font-size:13px;color:<?= $remaining>=0?'#52c48a':'#e05252' ?>;">Remaining: ₹<?= number_format(abs($remaining),2) ?><?= $remaining<0?' (Over)':'' ?></span>
      </div>
      <div style="height:20px;background:rgba(255,255,255,0.06);border-radius:10px;overflow:hidden;position:relative;">
        <div style="height:100%;width:<?= $spent_pct ?>%;background:<?= $spent_pct>=100?'linear-gradient(90deg,#e05252,#a03030)':($spent_pct>=80?'linear-gradient(90deg,#ffa500,#e08000)':'linear-gradient(90deg,var(--gold),var(--gold-dark))') ?>;border-radius:10px;transition:width 1s ease;box-shadow:0 0 10px rgba(201,168,76,0.3);display:flex;align-items:center;justify-content:center;">
          <?php if($spent_pct>15): ?><span style="font-size:11px;font-weight:700;color:var(--dark);"><?= $spent_pct ?>%</span><?php endif; ?>
        </div>
      </div>
      <div style="display:flex;justify-content:space-between;margin-top:6px;">
        <span style="font-size:11px;color:var(--text-dim);">₹0</span>
        <span style="font-size:11px;color:var(--gold);">Salary: ₹<?= number_format($salary,0) ?></span>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <!-- CHARTS -->
  <div class="charts-grid">
    <div class="chart-panel"><h3>🍩 Spending by Category</h3><canvas id="pieChart" height="260"></canvas></div>
    <div class="chart-panel"><h3>📊 Monthly Trend</h3><canvas id="barChart" height="260"></canvas></div>
  </div>

  <!-- CATEGORY BREAKDOWN -->
  <?php if(count($labels)>0): ?>
  <div class="panel">
    <div class="panel-header"><div class="panel-title">Category Breakdown</div></div>
    <table>
      <thead><tr><th>Category</th><th>Amount</th><th>% of Total</th><th>Bar</th></tr></thead>
      <tbody>
      <?php foreach($labels as $i=>$label):
        $pct=$grand>0?round(($amounts[$i]/$grand)*100,1):0; ?>
        <tr>
          <td><span class="cat-badge"><?= $label ?></span></td>
          <td><span class="amount">₹<?= number_format($amounts[$i],2) ?></span></td>
          <td style="color:var(--text-dim)"><?= $pct ?>%</td>
          <td style="width:200px;"><div style="background:rgba(255,255,255,0.05);border-radius:4px;height:8px;overflow:hidden;"><div style="width:<?= $pct ?>%;height:100%;background:linear-gradient(90deg,var(--gold),var(--gold-dark));border-radius:4px;"></div></div></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<script>
const colors=['#c9a84c','#8a6d2f','#f0d080','#52c48a','#5282e0','#e05252','#a052e0'];
new Chart(document.getElementById('pieChart'),{type:'doughnut',data:{labels:<?= json_encode($labels) ?>,datasets:[{data:<?= json_encode($amounts) ?>,backgroundColor:colors,borderColor:'#111118',borderWidth:3,hoverOffset:8}]},options:{responsive:true,cutout:'65%',plugins:{legend:{position:'bottom',labels:{color:'#e8e4d9',padding:16,font:{family:'DM Sans',size:12}}}}}});
new Chart(document.getElementById('barChart'),{type:'bar',data:{labels:<?= json_encode($months) ?>,datasets:[{label:'Monthly Expenses (₹)',data:<?= json_encode($mtotals) ?>,backgroundColor:'rgba(201,168,76,0.25)',borderColor:'#c9a84c',borderWidth:2,borderRadius:8,hoverBackgroundColor:'rgba(201,168,76,0.5)'}]},options:{responsive:true,plugins:{legend:{labels:{color:'#e8e4d9',font:{family:'DM Sans'}}}},scales:{x:{ticks:{color:'#e8e4d980'},grid:{color:'rgba(201,168,76,0.06)'}},y:{ticks:{color:'#e8e4d980'},grid:{color:'rgba(201,168,76,0.06)'}}}}});
</script>
</body>
</html>