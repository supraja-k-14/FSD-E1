<?php
session_start();
include 'db.php';
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email    = $_POST['email'];
    $password = $_POST['password'];
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);
    $user = mysqli_fetch_assoc($result);
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id']  = $user['id'];
        $_SESSION['username'] = $user['username'];
        header("Location: index.php");
        exit();
    } else {
        $error = "Invalid email or password!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — TrackWise</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="bg-scene"></div>
<div class="bg-grid"></div>
<div class="bg-orb bg-orb-1"></div>
<div class="bg-orb bg-orb-2"></div>

<div class="auth-wrapper">
    <!-- LEFT HERO -->
    <div class="auth-hero">
        <div class="auth-hero-img"></div>
        <div class="auth-hero-content">
            <div class="brand-logo">
                <div class="brand-icon">💰</div>
                <div class="brand-name">TRACKWISE</div>
            </div>
            <h2>Welcome<br><span>Back.</span></h2>
            <p>Your expenses have been waiting. Sign in to pick up right where you left off.</p>
            <div class="auth-stats">
                <div class="auth-stat">
                    <div class="num">Real-Time</div>
                    <div class="lbl">Analytics</div>
                </div>
                <div class="auth-stat">
                    <div class="num">Smart</div>
                    <div class="lbl">Categories</div>
                </div>
                <div class="auth-stat">
                    <div class="num">Visual</div>
                    <div class="lbl">Charts</div>
                </div>
            </div>
        </div>
    </div>

    <!-- RIGHT FORM -->
    <div class="auth-panel">
        <div class="form-box">
            <h2>Sign In</h2>
            <p class="subtitle">Enter your credentials to continue</p>

            <?php if($error): ?>
                <div class="error-msg">⚠️ <?= $error ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="input-group">
                    <label>Email Address</label>
                    <input type="email" name="email" placeholder="you@example.com" required>
                </div>
                <div class="input-group">
                    <label>Password</label>
                    <input type="password" name="password" placeholder="Your password" required>
                </div>
                <button type="submit" class="btn btn-full">Sign In →</button>
            </form>

            <p class="auth-link">Don't have an account? <a href="register.php">Register Free</a></p>
        </div>
    </div>
</div>
</body>
</html>