<?php
include 'db.php';
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email    = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')";
    if (mysqli_query($conn, $sql)) {
        header("Location: login.php");
        exit();
    } else {
        $error = "Username or email already exists!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register — TrackWise</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="bg-scene"></div>
<div class="bg-grid"></div>
<div class="bg-orb bg-orb-1"></div>
<div class="bg-orb bg-orb-2"></div>

<div class="auth-wrapper">
    <!-- LEFT HERO -->
    <div class="auth-hero">
        <div class="auth-hero-img"></div>
        <div class="auth-hero-content">
            <div class="brand-logo">
                <div class="brand-icon">💰</div>
                <div class="brand-name">TRACKWISE</div>
            </div>
            <h2>Master Your<br><span>Financial Future</span></h2>
            <p>Join thousands of smart spenders who track, analyse and optimise their expenses with TrackWise.</p>
            <div class="auth-stats">
                <div class="auth-stat">
                    <div class="num">10K+</div>
                    <div class="lbl">Users</div>
                </div>
                <div class="auth-stat">
                    <div class="num">₹2M+</div>
                    <div class="lbl">Tracked</div>
                </div>
                <div class="auth-stat">
                    <div class="num">99%</div>
                    <div class="lbl">Accurate</div>
                </div>
            </div>
        </div>
    </div>

    <!-- RIGHT FORM -->
    <div class="auth-panel">
        <div class="form-box">
            <h2>Create Account</h2>
            <p class="subtitle">Start your financial journey today</p>

            <?php if($error): ?>
                <div class="error-msg">⚠️ <?= $error ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="input-group">
                    <label>Username</label>
                    <input type="text" name="username" placeholder="e.g. divij123" required>
                </div>
                <div class="input-group">
                    <label>Email Address</label>
                    <input type="email" name="email" placeholder="you@example.com" required>
                </div>
                <div class="input-group">
                    <label>Password</label>
                    <input type="password" name="password" placeholder="Create a strong password" required>
                </div>
                <button type="submit" class="btn btn-full">Create My Account →</button>
            </form>

            <p class="auth-link">Already have an account? <a href="login.php">Sign In</a></p>
        </div>
    </div>
</div>
</body>
</html>