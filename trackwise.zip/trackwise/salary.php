<?php
session_start();
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
include 'db.php';
$user_id  = $_SESSION['user_id'];
$username = $_SESSION['username'];

// Get current salary
$user_r  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT salary, salary_updated FROM users WHERE id='$user_id'"));
$salary  = $user_r['salary'] ?? 0;
$updated = $user_r['salary_updated'] ?? null;

$success = '';
$error   = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_salary = $_POST['salary'];
    if ($new_salary < 0) {
        $error = "Salary cannot be negative!";
    } else {
        mysqli_query($conn, "UPDATE users SET salary='$new_salary', salary_updated=CURDATE() WHERE id='$user_id'");
        $salary  = $new_salary;
        $updated = date('Y-m-d');
        $success = "Salary updated successfully!";
    }
}

// Get this month stats
$month_r  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(amount) as t FROM expenses WHERE user_id='$user_id' AND MONTH(expense_date)=MONTH(NOW()) AND YEAR(expense_date)=YEAR(NOW())"));
$month    = $month_r['t'] ?? 0;
$remaining = $salary - $month;
$spent_pct = $salary > 0 ? min(round(($month/$salary)*100),100) : 0;

// Monthly history
$history = mysqli_query($conn, "SELECT DATE_FORMAT(expense_date,'%b %Y') as month, MONTH(expense_date) as m, YEAR(expense_date) as y, SUM(amount) as total FROM expenses WHERE user_id='$user_id' GROUP BY YEAR(expense_date),MONTH(expense_date) ORDER BY expense_date DESC LIMIT 6");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Salary Manager — TrackWise</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="bg-scene"></div>
<div class="bg-grid"></div>
<div class="bg-orb bg-orb-1"></div>
<div class="bg-orb bg-orb-2"></div>
<div class="bg-orb bg-orb-3"></div>

<nav class="topbar">
  <a href="index.php" class="topbar-brand"><div class="icon">💰</div><div class="name">TRACKWISE</div></a>
  <div class="topbar-nav">
    <a href="add_expense.php" class="btn btn-gold btn-sm">+ Add Expense</a>
    <a href="expenses.php" class="btn btn-ghost btn-sm">📋 Expenses</a>
    <a href="analytics.php" class="btn btn-ghost btn-sm">📊 Analytics</a>
    <a href="index.php" class="btn btn-ghost btn-sm">🏠 Dashboard</a>
    <a href="logout.php" class="btn btn-red btn-sm">Logout</a>
  </div>
  <div class="topbar-user">
    <div class="avatar"><?= strtoupper(substr($username,0,1)) ?></div>
    <span><?= htmlspecialchars($username) ?></span>
  </div>
</nav>

<div class="main-content">
  <div class="page-header">
    <h1>💼 Salary <span>Manager</span></h1>
    <p>Set your monthly salary and track your savings automatically</p>
  </div>

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:25px;align-items:start;">

    <!-- LEFT: FORM + CURRENT STATUS -->
    <div>
      <!-- SET SALARY FORM -->
      <div class="panel">
        <div class="panel-header">
          <div class="panel-title">💼 Set Monthly Salary</div>
        </div>

        <?php if($success): ?>
        <div style="background:rgba(82,196,138,0.12);border:1px solid rgba(82,196,138,0.3);color:#52c48a;padding:12px 16px;border-radius:10px;font-size:13px;margin-bottom:20px;">✅ <?= $success ?></div>
        <?php endif; ?>

        <?php if($error): ?>
        <div class="error-msg">⚠️ <?= $error ?></div>
        <?php endif; ?>

        <form method="POST">
          <div class="input-group">
            <label>Monthly Salary (₹)</label>
            <input type="number" step="0.01" name="salary" value="<?= $salary ?>" placeholder="Enter your monthly salary" required>
          </div>
          <button type="submit" class="btn btn-full">💾 Save Salary</button>
        </form>

        <?php if($updated): ?>
        <div style="text-align:center;margin-top:14px;font-size:12px;color:var(--text-dim);">
          Last updated: <?= date('d M Y', strtotime($updated)) ?>
        </div>
        <?php endif; ?>
      </div>

      <!-- BUDGET STATUS -->
      <?php if($salary > 0): ?>
      <div class="panel">
        <div class="panel-header">
          <div class="panel-title">📊 <?= date('F Y') ?> Status</div>
        </div>

        <!-- PROGRESS BAR -->
        <div style="margin-bottom:20px;">
          <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
            <span style="font-size:13px;color:var(--text-dim);">Spent <?= $spent_pct ?>%</span>
            <span style="font-size:13px;color:var(--gold);">₹<?= number_format($month,2) ?> / ₹<?= number_format($salary,2) ?></span>
          </div>
          <div style="height:16px;background:rgba(255,255,255,0.08);border-radius:10px;overflow:hidden;">
            <div style="height:100%;width:<?= $spent_pct ?>%;background:<?= $spent_pct>=100?'linear-gradient(90deg,#e05252,#a03030)':($spent_pct>=80?'linear-gradient(90deg,#ffa500,#e08000)':'linear-gradient(90deg,var(--gold),var(--gold-dark))') ?>;border-radius:10px;transition:width 1s ease;box-shadow:0 0 10px rgba(201,168,76,0.3);"></div>
          </div>
        </div>

        <!-- STATUS CARDS -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
          <div style="background:rgba(201,168,76,0.08);border:1px solid rgba(201,168,76,0.2);border-radius:12px;padding:16px;text-align:center;">
            <div style="font-size:11px;color:var(--text-dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Monthly Salary</div>
            <div style="font-family:'Playfair Display',serif;font-size:24px;font-weight:700;color:var(--gold-light);">₹<?= number_format($salary,0) ?></div>
          </div>
          <div style="background:rgba(224,82,82,0.08);border:1px solid rgba(224,82,82,0.2);border-radius:12px;padding:16px;text-align:center;">
            <div style="font-size:11px;color:var(--text-dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Spent</div>
            <div style="font-family:'Playfair Display',serif;font-size:24px;font-weight:700;color:#e05252;">₹<?= number_format($month,0) ?></div>
          </div>
          <div style="background:rgba(82,196,138,0.08);border:1px solid rgba(82,196,138,0.2);border-radius:12px;padding:16px;text-align:center;">
            <div style="font-size:11px;color:var(--text-dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;"><?= $remaining>=0?'Savings':'Over Budget' ?></div>
            <div style="font-family:'Playfair Display',serif;font-size:24px;font-weight:700;color:<?= $remaining>=0?'#52c48a':'#e05252' ?>;">₹<?= number_format(abs($remaining),0) ?></div>
          </div>
          <div style="background:rgba(82,130,224,0.08);border:1px solid rgba(82,130,224,0.2);border-radius:12px;padding:16px;text-align:center;">
            <div style="font-size:11px;color:var(--text-dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Savings %</div>
            <div style="font-family:'Playfair Display',serif;font-size:24px;font-weight:700;color:#5282e0;"><?= max(0,100-$spent_pct) ?>%</div>
          </div>
        </div>
      </div>
      <?php endif; ?>
    </div>

    <!-- RIGHT: TIPS + HISTORY -->
    <div>
      <!-- SAVINGS TIPS -->
      <div class="panel">
        <div class="panel-header">
          <div class="panel-title">💡 Smart Budget Tips</div>
        </div>
        <div style="display:flex;flex-direction:column;gap:14px;">
          <div style="display:flex;gap:14px;align-items:flex-start;padding:14px;background:rgba(201,168,76,0.05);border-radius:10px;border:1px solid rgba(201,168,76,0.1);">
            <div style="font-size:24px;flex-shrink:0;">🏠</div>
            <div>
              <div style="font-weight:600;color:var(--text);margin-bottom:3px;">50% Rule</div>
              <div style="font-size:13px;color:var(--text-dim);">Spend 50% on needs, 30% on wants, save 20% of your salary</div>
              <?php if($salary>0): ?>
              <div style="font-size:12px;color:var(--gold);margin-top:5px;">Save target: ₹<?= number_format($salary*0.2,0) ?>/month</div>
              <?php endif; ?>
            </div>
          </div>
          <div style="display:flex;gap:14px;align-items:flex-start;padding:14px;background:rgba(82,196,138,0.05);border-radius:10px;border:1px solid rgba(82,196,138,0.1);">
            <div style="font-size:24px;flex-shrink:0;">🎯</div>
            <div>
              <div style="font-weight:600;color:var(--text);margin-bottom:3px;">Daily Budget</div>
              <div style="font-size:13px;color:var(--text-dim);">Break your monthly limit into a daily spending goal</div>
              <?php if($salary>0): ?>
              <div style="font-size:12px;color:#52c48a;margin-top:5px;">Daily limit: ₹<?= number_format($salary/30,0) ?>/day</div>
              <?php endif; ?>
            </div>
          </div>
          <div style="display:flex;gap:14px;align-items:flex-start;padding:14px;background:rgba(82,130,224,0.05);border-radius:10px;border:1px solid rgba(82,130,224,0.1);">
            <div style="font-size:24px;flex-shrink:0;">⚠️</div>
            <div>
              <div style="font-weight:600;color:var(--text);margin-bottom:3px;">Alert Zones</div>
              <div style="font-size:13px;color:var(--text-dim);">You get alerts when you cross 50%, 80% and 100% of salary</div>
              <?php if($salary>0): ?>
              <div style="font-size:12px;color:#5282e0;margin-top:5px;">80% alert at: ₹<?= number_format($salary*0.8,0) ?></div>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>

      <!-- MONTHLY HISTORY -->
      <div class="panel">
        <div class="panel-header">
          <div class="panel-title">📅 Monthly History</div>
        </div>
        <?php if(mysqli_num_rows($history)>0): ?>
        <div style="display:flex;flex-direction:column;gap:10px;">
          <?php while($row=mysqli_fetch_assoc($history)):
            $pct = $salary>0?min(round(($row['total']/$salary)*100),100):0;
            $saved = $salary-$row['total'];
          ?>
          <div style="background:rgba(255,255,255,0.02);border:1px solid rgba(201,168,76,0.1);border-radius:10px;padding:14px;">
            <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
              <span style="font-weight:600;color:var(--text);font-size:14px;"><?= $row['month'] ?></span>
              <div style="display:flex;gap:12px;">
                <span style="font-size:13px;color:#e05252;">Spent: ₹<?= number_format($row['total'],0) ?></span>
                <?php if($salary>0): ?>
                <span style="font-size:13px;color:<?= $saved>=0?'#52c48a':'#e05252' ?>;"><?= $saved>=0?'Saved':'Over' ?>: ₹<?= number_format(abs($saved),0) ?></span>
                <?php endif; ?>
              </div>
            </div>
            <?php if($salary>0): ?>
            <div style="height:6px;background:rgba(255,255,255,0.06);border-radius:4px;overflow:hidden;">
              <div style="height:100%;width:<?= $pct ?>%;background:<?= $pct>=100?'#e05252':($pct>=80?'#ffa500':'var(--gold)') ?>;border-radius:4px;"></div>
            </div>
            <div style="font-size:11px;color:var(--text-dim);margin-top:5px;"><?= $pct ?>% of salary used</div>
            <?php endif; ?>
          </div>
          <?php endwhile; ?>
        </div>
        <?php else: ?>
        <div class="empty">
          <div class="empty-icon">📅</div>
          <h3>No history yet</h3>
          <p>Start adding expenses to see monthly history</p>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
</body>
</html>