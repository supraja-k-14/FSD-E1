<?php
session_start();
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
include 'db.php';
$user_id  = $_SESSION['user_id'];
$username = $_SESSION['username'];
$cats = mysqli_query($conn, "SELECT * FROM categories");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title       = $_POST['title'];
    $amount      = $_POST['amount'];
    $category_id = $_POST['category_id'];
    $date        = $_POST['expense_date'];
    $notes       = $_POST['notes'];
    $sql = "INSERT INTO expenses (user_id, category_id, title, amount, expense_date, notes) VALUES ('$user_id','$category_id','$title','$amount','$date','$notes')";
    mysqli_query($conn, $sql);
    header("Location: expenses.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Expense — TrackWise</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="bg-scene"></div>
<div class="bg-grid"></div>
<div class="bg-orb bg-orb-1"></div>
<div class="bg-orb bg-orb-2"></div>

<nav class="topbar">
    <a href="index.php" class="topbar-brand">
        <div class="icon">💰</div>
        <div class="name">TRACKWISE</div>
    </a>
    <div class="topbar-nav">
        <a href="expenses.php" class="btn btn-ghost btn-sm">📋 Expenses</a>
        <a href="analytics.php" class="btn btn-ghost btn-sm">📊 Analytics</a>
        <a href="index.php" class="btn btn-ghost btn-sm">🏠 Dashboard</a>
        <a href="logout.php" class="btn btn-red btn-sm">Logout</a>
    </div>
    <div class="topbar-user">
        <div class="avatar"><?= strtoupper(substr($username,0,1)) ?></div>
        <span><?= htmlspecialchars($username) ?></span>
    </div>
</nav>

<div class="main-content">
    <div class="page-header">
        <h1>Add <span>New Expense</span></h1>
        <p>Record a new transaction to keep your finances accurate</p>
    </div>

    <div style="display:grid; grid-template-columns:1fr 1fr; gap:25px; align-items:start;">

        <!-- FORM -->
        <div class="panel">
            <div class="panel-header">
                <div class="panel-title">Expense Details</div>
            </div>
            <form method="POST">
                <div class="input-group">
                    <label>Expense Title</label>
                    <input type="text" name="title" placeholder="e.g. Lunch at restaurant" required>
                </div>
                <div class="input-group">
                    <label>Amount (₹)</label>
                    <input type="number" step="0.01" name="amount" placeholder="0.00" required>
                </div>
                <div class="input-group">
                    <label>Category</label>
                    <select name="category_id" required>
                        <option value="">Select a category</option>
                        <?php while($cat = mysqli_fetch_assoc($cats)): ?>
                            <option value="<?= $cat['id'] ?>"><?= $cat['name'] ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="input-group">
                    <label>Date</label>
                    <input type="date" name="expense_date" value="<?= date('Y-m-d') ?>" required>
                </div>
                <div class="input-group">
                    <label>Notes (Optional)</label>
                    <textarea name="notes" placeholder="Any additional details..."></textarea>
                </div>
                <button type="submit" class="btn btn-full">Save Expense →</button>
            </form>
        </div>

        <!-- RIGHT SIDE INFO -->
        <div>
            <div style="
                border-radius:16px;
                overflow:hidden;
                margin-bottom:20px;
                height:220px;
                background: url('https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=600&q=80') center/cover;
                position:relative;
            ">
                <div style="position:absolute; inset:0; background:linear-gradient(to top, rgba(10,10,15,0.9), transparent);"></div>
                <div style="position:absolute; bottom:20px; left:20px; right:20px;">
                    <div style="font-family:'Playfair Display',serif; font-size:20px; font-weight:700; color:white;">Track Every Rupee</div>
                    <div style="font-size:13px; color:rgba(255,255,255,0.6); margin-top:4px;">Small habits lead to big savings</div>
                </div>
            </div>

            <div class="panel">
                <div class="panel-title" style="margin-bottom:16px;">💡 Quick Tips</div>
                <div style="display:flex; flex-direction:column; gap:12px;">
                    <div style="display:flex; gap:12px; align-items:flex-start;">
                        <div style="width:32px; height:32px; background:rgba(201,168,76,0.15); border-radius:8px; display:flex; align-items:center; justify-content:center; flex-shrink:0;">🍽️</div>
                        <div>
                            <div style="font-size:13px; font-weight:600; color:var(--text)">Food & Dining</div>
                            <div style="font-size:12px; color:var(--text-dim)">Track meals, groceries, snacks</div>
                        </div>
                    </div>
                    <div style="display:flex; gap:12px; align-items:flex-start;">
                        <div style="width:32px; height:32px; background:rgba(82,196,138,0.15); border-radius:8px; display:flex; align-items:center; justify-content:center; flex-shrink:0;">🚗</div>
                        <div>
                            <div style="font-size:13px; font-weight:600; color:var(--text)">Transport</div>
                            <div style="font-size:12px; color:var(--text-dim)">Fuel, cab, bus, metro</div>
                        </div>
                    </div>
                    <div style="display:flex; gap:12px; align-items:flex-start;">
                        <div style="width:32px; height:32px; background:rgba(82,130,224,0.15); border-radius:8px; display:flex; align-items:center; justify-content:center; flex-shrink:0;">🏥</div>
                        <div>
                            <div style="font-size:13px; font-weight:600; color:var(--text)">Health</div>
                            <div style="font-size:12px; color:var(--text-dim)">Medicine, doctor, gym</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>