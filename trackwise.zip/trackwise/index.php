<?php
session_start();
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
include 'db.php';
$user_id  = $_SESSION['user_id'];
$username = $_SESSION['username'];

// Get user salary
$user_r  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT salary FROM users WHERE id='$user_id'"));
$salary  = $user_r['salary'] ?? 0;

// Stats
$total_r  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(amount) as t FROM expenses WHERE user_id='$user_id'"));
$total    = $total_r['t'] ?? 0;
$month_r  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(amount) as t FROM expenses WHERE user_id='$user_id' AND MONTH(expense_date)=MONTH(NOW()) AND YEAR(expense_date)=YEAR(NOW())"));
$month    = $month_r['t'] ?? 0;
$count_r  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM expenses WHERE user_id='$user_id'"));
$count    = $count_r['c'] ?? 0;
$top_r    = mysqli_fetch_assoc(mysqli_query($conn, "SELECT c.name, SUM(e.amount) as t FROM expenses e JOIN categories c ON e.category_id=c.id WHERE e.user_id='$user_id' GROUP BY c.name ORDER BY t DESC LIMIT 1"));
$top_cat  = $top_r['name'] ?? '—';
$recent   = mysqli_query($conn, "SELECT e.*, c.name as category FROM expenses e JOIN categories c ON e.category_id=c.id WHERE e.user_id='$user_id' ORDER BY e.created_at DESC LIMIT 6");

// Salary calculations
$remaining   = $salary - $month;
$savings_pct = $salary > 0 ? round(($remaining / $salary) * 100) : 0;
$spent_pct   = $salary > 0 ? round(($month / $salary) * 100) : 0;
$spent_pct   = min($spent_pct, 100);

// Warning level
$warning = '';
if ($salary > 0) {
    if ($month >= $salary) $warning = 'danger';
    elseif ($month >= $salary * 0.8) $warning = 'warning';
    elseif ($month >= $salary * 0.5) $warning = 'caution';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Dashboard — TrackWise</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="bg-scene"></div>
<div class="bg-grid"></div>
<div class="bg-orb bg-orb-1"></div>
<div class="bg-orb bg-orb-2"></div>
<div class="bg-orb bg-orb-3"></div>

<nav class="topbar">
  <a href="index.php" class="topbar-brand"><div class="icon">💰</div><div class="name">TRACKWISE</div></a>
  <div class="topbar-nav">
    <a href="add_expense.php" class="btn btn-gold btn-sm">+ Add Expense</a>
    <a href="expenses.php" class="btn btn-ghost btn-sm">📋 Expenses</a>
    <a href="analytics.php" class="btn btn-ghost btn-sm">📊 Analytics</a>
    <a href="salary.php" class="btn btn-ghost btn-sm">💼 Salary</a>
    <a href="logout.php" class="btn btn-red btn-sm">Logout</a>
  </div>
  <div class="topbar-user">
    <div class="avatar"><?= strtoupper(substr($username,0,1)) ?></div>
    <span><?= htmlspecialchars($username) ?></span>
  </div>
</nav>

<div class="main-content">
  <div class="page-header">
    <h1>Good <?= date('H')<12?'Morning':(date('H')<17?'Afternoon':'Evening') ?>, <span><?= htmlspecialchars($username) ?></span> 👋</h1>
    <p><?= date('l, F j, Y') ?></p>
  </div>

  <!-- WARNING BANNERS -->
  <?php if($warning == 'danger'): ?>
  <div style="background:rgba(224,82,82,0.15);border:1px solid rgba(224,82,82,0.4);border-radius:14px;padding:18px 24px;margin-bottom:25px;display:flex;align-items:center;gap:14px;animation:fadeSlideUp 0.5s ease;">
    <div style="font-size:28px;">🚨</div>
    <div>
      <div style="font-family:'Playfair Display',serif;font-size:18px;font-weight:700;color:#e05252;">Budget Exceeded!</div>
      <div style="font-size:13px;color:var(--text-dim);margin-top:3px;">You have spent ₹<?= number_format($month,2) ?> which exceeds your salary of ₹<?= number_format($salary,2) ?>. Please review your expenses!</div>
    </div>
  </div>
  <?php elseif($warning == 'warning'): ?>
  <div style="background:rgba(255,165,0,0.12);border:1px solid rgba(255,165,0,0.35);border-radius:14px;padding:18px 24px;margin-bottom:25px;display:flex;align-items:center;gap:14px;animation:fadeSlideUp 0.5s ease;">
    <div style="font-size:28px;">⚠️</div>
    <div>
      <div style="font-family:'Playfair Display',serif;font-size:18px;font-weight:700;color:#ffa500;">High Spending Alert!</div>
      <div style="font-size:13px;color:var(--text-dim);margin-top:3px;">You've used <?= $spent_pct ?>% of your salary. Only ₹<?= number_format($remaining,2) ?> remaining this month!</div>
    </div>
  </div>
  <?php elseif($warning == 'caution'): ?>
  <div style="background:rgba(201,168,76,0.1);border:1px solid rgba(201,168,76,0.3);border-radius:14px;padding:18px 24px;margin-bottom:25px;display:flex;align-items:center;gap:14px;animation:fadeSlideUp 0.5s ease;">
    <div style="font-size:28px;">💡</div>
    <div>
      <div style="font-family:'Playfair Display',serif;font-size:18px;font-weight:700;color:var(--gold-light);">Spending Notice</div>
      <div style="font-size:13px;color:var(--text-dim);margin-top:3px;">You've used <?= $spent_pct ?>% of your salary. ₹<?= number_format($remaining,2) ?> remaining — spend wisely!</div>
    </div>
  </div>
  <?php endif; ?>

  <!-- HERO BANNER -->
  <?php if($salary > 0): ?>
  <div style="background:linear-gradient(135deg,rgba(201,168,76,0.12),rgba(120,80,200,0.08));border:1px solid rgba(201,168,76,0.2);border-radius:20px;padding:35px 40px;margin-bottom:25px;position:relative;overflow:hidden;animation:fadeSlideUp 0.5s ease;">
    <div style="position:absolute;inset:0;background:url('https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?w=1200&q=60') center/cover;opacity:0.06;"></div>
    <div style="position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,transparent,var(--gold),transparent);"></div>
    <div style="position:relative;z-index:1;">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:20px;margin-bottom:25px;">
        <div>
          <div style="font-size:12px;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:6px;">Monthly Budget Overview — <?= date('F Y') ?></div>
          <div style="font-family:'Playfair Display',serif;font-size:14px;color:var(--text-dim);">Salary: <span style="color:var(--gold-light);font-weight:700;">₹<?= number_format($salary,2) ?></span></div>
        </div>
        <a href="salary.php" class="btn btn-ghost btn-sm">✏️ Update Salary</a>
      </div>

      <!-- PROGRESS BAR -->
      <div style="margin-bottom:16px;">
        <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
          <span style="font-size:13px;color:var(--text-dim);">Spent: ₹<?= number_format($month,2) ?> (<?= $spent_pct ?>%)</span>
          <span style="font-size:13px;color:<?= $remaining>=0?'#52c48a':'#e05252' ?>;">Remaining: ₹<?= number_format(abs($remaining),2) ?><?= $remaining<0?' (Over Budget)':'' ?></span>
        </div>
        <div style="height:14px;background:rgba(255,255,255,0.08);border-radius:10px;overflow:hidden;">
          <div style="height:100%;width:<?= $spent_pct ?>%;background:<?= $warning=='danger'?'linear-gradient(90deg,#e05252,#a03030)':($warning=='warning'?'linear-gradient(90deg,#ffa500,#e08000)':'linear-gradient(90deg,var(--gold),var(--gold-dark))') ?>;border-radius:10px;transition:width 1s ease;box-shadow:0 0 10px rgba(201,168,76,0.3);"></div>
        </div>
      </div>

      <!-- MINI SALARY STATS -->
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:15px;">
        <div style="background:rgba(255,255,255,0.04);border:1px solid rgba(201,168,76,0.1);border-radius:12px;padding:15px;text-align:center;">
          <div style="font-size:11px;color:var(--text-dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Monthly Salary</div>
          <div style="font-family:'Playfair Display',serif;font-size:22px;font-weight:700;color:var(--gold-light);">₹<?= number_format($salary,0) ?></div>
        </div>
        <div style="background:rgba(255,255,255,0.04);border:1px solid rgba(224,82,82,0.15);border-radius:12px;padding:15px;text-align:center;">
          <div style="font-size:11px;color:var(--text-dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Spent This Month</div>
          <div style="font-family:'Playfair Display',serif;font-size:22px;font-weight:700;color:#e05252;">₹<?= number_format($month,0) ?></div>
        </div>
        <div style="background:rgba(255,255,255,0.04);border:1px solid rgba(82,196,138,0.15);border-radius:12px;padding:15px;text-align:center;">
          <div style="font-size:11px;color:var(--text-dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;"><?= $remaining>=0?'Savings':'Over Budget' ?></div>
          <div style="font-family:'Playfair Display',serif;font-size:22px;font-weight:700;color:<?= $remaining>=0?'#52c48a':'#e05252' ?>;">₹<?= number_format(abs($remaining),0) ?></div>
        </div>
      </div>
    </div>
  </div>
  <?php else: ?>
  <!-- NO SALARY SET -->
  <div style="background:rgba(201,168,76,0.08);border:1px dashed rgba(201,168,76,0.3);border-radius:16px;padding:30px;text-align:center;margin-bottom:25px;animation:fadeSlideUp 0.5s ease;">
    <div style="font-size:40px;margin-bottom:12px;">💼</div>
    <div style="font-family:'Playfair Display',serif;font-size:20px;font-weight:700;color:var(--gold-light);margin-bottom:8px;">Set Your Monthly Salary</div>
    <div style="font-size:14px;color:var(--text-dim);margin-bottom:20px;">Add your salary to track savings, budget alerts and spending limits!</div>
    <a href="salary.php" class="btn btn-gold" style="padding:12px 30px;">💼 Set Salary Now</a>
  </div>
  <?php endif; ?>

  <!-- STAT CARDS -->
  <div class="stats-grid">
    <div class="stat-card card-gold" style="animation-delay:0.1s">
      <div class="card-icon">💸</div>
      <div class="card-label">This Month</div>
      <div class="card-value">₹<?= number_format($month,0) ?></div>
      <div class="card-sub"><?= date('F Y') ?></div>
    </div>
    <div class="stat-card card-green" style="animation-delay:0.2s">
      <div class="card-icon">🏦</div>
      <div class="card-label"><?= $salary>0?'Savings':'Transactions' ?></div>
      <div class="card-value"><?= $salary>0?'₹'.number_format(max($remaining,0),0):$count ?></div>
      <div class="card-sub"><?= $salary>0?($remaining>=0?'Saved this month':'Over budget'):'Total recorded' ?></div>
    </div>
    <div class="stat-card card-blue" style="animation-delay:0.3s">
      <div class="card-icon">🏆</div>
      <div class="card-label">Top Category</div>
      <div class="card-value" style="font-size:20px;margin-top:4px;"><?= $top_cat ?></div>
      <div class="card-sub">Highest spending</div>
    </div>
    <div class="stat-card card-red" style="animation-delay:0.4s">
      <div class="card-icon">📊</div>
      <div class="card-label"><?= $salary>0?'Budget Used':'Avg/Month' ?></div>
      <div class="card-value"><?= $salary>0?$spent_pct.'%':'₹'.number_format($total/max(1,(int)date('n')),0) ?></div>
      <div class="card-sub"><?= $salary>0?'Of monthly salary':'Estimated average' ?></div>
    </div>
  </div>

  <!-- RECENT -->
  <div class="panel">
    <div class="panel-header">
      <div class="panel-title">Recent Transactions</div>
      <a href="expenses.php" class="btn btn-ghost btn-sm">View All →</a>
    </div>
    <?php if(mysqli_num_rows($recent)>0): ?>
    <table>
      <thead><tr><th>Date</th><th>Title</th><th>Category</th><th>Amount</th></tr></thead>
      <tbody>
      <?php while($row=mysqli_fetch_assoc($recent)): ?>
        <tr>
          <td style="color:var(--text-dim)"><?= date('d M Y',strtotime($row['expense_date'])) ?></td>
          <td><?= htmlspecialchars($row['title']) ?></td>
          <td><span class="cat-badge"><?= $row['category'] ?></span></td>
          <td><span class="amount">₹<?= number_format($row['amount'],2) ?></span></td>
        </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
    <?php else: ?>
    <div class="empty">
      <div class="empty-icon">💳</div>
      <h3>No expenses yet</h3>
      <p>Add your first expense to get started</p>
      <br><a href="add_expense.php" class="btn">+ Add Expense</a>
    </div>
    <?php endif; ?>
  </div>
</div>
</body>
</html>